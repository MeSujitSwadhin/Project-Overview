import { redirect, LoaderFunctionArgs } from '@remix-run/node';
import { Outlet } from '@remix-run/react';

export async function loader({ request }: LoaderFunctionArgs) {
    const cookies = request.headers.get('Cookie');
    if (cookies && cookies.includes('access_token')) {
        throw redirect('/profile');
    }
    throw redirect('/signin');
}

export default function Index() {
    return null;
}
