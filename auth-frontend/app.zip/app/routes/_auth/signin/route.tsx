import { useState } from "react";
import { useNavigate } from "@remix-run/react";
import axios from "axios";
import toast from "react-hot-toast";
import AuthForm from "~/components/AuthForm";

export default function Signin() {
    const navigate = useNavigate();
    const [form, setForm] = useState({ emailOrMobile: "", password: "" });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) =>
        setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:5000/api/auth/login', form, { withCredentials: true });
            toast.success('Login successful! 🎉');
            navigate('/profile');
        } catch (err) {
            toast.error('Invalid credentials. Please try again.');
        }
    };

    return (
        <AuthForm
            title="Welcome Back"
            buttonText="Login"
            bgColor="bg-gradient-to-r from-blue-100 via-white to-blue-100"
            fields={[
                {
                    name: "emailOrMobile",
                    type: "text",
                    placeholder: "Email or Mobile",
                    value: form.emailOrMobile,
                    onChange: handleChange,
                },
                {
                    name: "password",
                    type: "password",
                    placeholder: "Password",
                    value: form.password,
                    onChange: handleChange,
                },
            ]}
            onSubmit={handleSubmit}
            linkText="Don't have an account?"
            linkHref="/signup"
        />
    );
}
