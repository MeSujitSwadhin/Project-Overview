import { useState } from "react";
import { useNavigate } from "@remix-run/react";
import axios from "axios";
import toast from "react-hot-toast";
import AuthForm from "~/components/AuthForm";

export default function Signup() {
    const navigate = useNavigate();
    const [form, setForm] = useState({ name: "", email: "", password: "", mobile: "" });

    const handleChange = (e: React.ChangeEvent<HTMLInputElement>) =>
        setForm({ ...form, [e.target.name]: e.target.value });

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:5000/api/auth/register', form, { withCredentials: true });
            toast.success('User registered successfully 🎉');
            navigate('/login');
        } catch (error: any) {
            const message = error.response?.data?.message || 'Something went wrong. Please try again.';
            toast.error(message);
        }
    };

    return (
        <AuthForm
            title="Create Account"
            buttonText="Register"
            bgColor="bg-gradient-to-r from-green-100 via-white to-green-100"
            fields={[
                {
                    name: "name",
                    type: "text",
                    placeholder: "Full Name",
                    value: form.name,
                    onChange: handleChange,
                },
                {
                    name: "email",
                    type: "email",
                    placeholder: "Email Address",
                    value: form.email,
                    onChange: handleChange,
                },
                {
                    name: "password",
                    type: "password",
                    placeholder: "Password",
                    value: form.password,
                    onChange: handleChange,
                },
                {
                    name: "mobile",
                    type: "text",
                    placeholder: "Mobile Number",
                    value: form.mobile,
                    onChange: handleChange,
                },
            ]}
            onSubmit={handleSubmit}
            linkText="Already have an account?"
            linkHref="/login"
        />
    );
}
